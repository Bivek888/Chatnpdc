// chatbot.js

function initializeChatbot() {
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');

    const responses = {
        "नाम के हो": "मेरो नाम हो ।",
        "नमस्ते": "नमस्ते। हजुरलाई के सेवा गर्न सक्छु ?",
        "कति बज्यो": new Date().toLocaleTimeString(),
        "सहयोग गर्न सक्नुहुन्छ": "मा तपाईंलाई आफूले सक्दो सहयोग गर्छु !",
    };

    function matchQuestion(userInput) {
        for (const question in responses) {
            if (new RegExp(question, 'i').test(userInput)) {
                return responses[question];
            }
        }
        return "माफ गर्नुहोस् । मलाई यसको जवाफ थाहा छैन ।";
    }

    function addMessage(message, sender) {
        const div = document.createElement('div');
        div.classList.add('message', sender === 'user' ? 'user-message' : 'chatbot-message');
        div.innerText = message;

        // Append message to the bottom
        chatMessages.appendChild(div);

        // Scroll chat messages container to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Add initial message
    addMessage("तपाईंले ताव वा बुद्ध बिहार सम्बन्धी प्रश्न सोध्न सक्नु हुन्छ ...", 'chatbot');

    function processUserInput() {
        const message = userInput.value.trim();
        if (message !== '') {
            addMessage(message, 'user');
            const response = matchQuestion(message);
            addMessage(response, 'chatbot');
            userInput.value = '';
        }
    }

    userInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            processUserInput();
        }
    });

    // Start with the chat scrolled to the bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

window.addEventListener('load', initializeChatbot);
